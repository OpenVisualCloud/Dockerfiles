#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x32e21920, "module_layout" },
	{ 0xa24f23d8, "__request_module" },
	{ 0x26087692, "kmalloc_caches" },
	{ 0x70301bb0, "vqat_ring_pair_reset" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x6ababb05, "debugfs_create_dir" },
	{ 0x78a31f11, "pci_read_config_byte" },
	{ 0xdd76bbfd, "adf_cfg_section_add" },
	{ 0x6aa26032, "adf_vqat_isr_resource_free" },
	{ 0x362f9a8, "__x86_indirect_thunk_r12" },
	{ 0x7eae295f, "dma_set_mask" },
	{ 0xfb14ff3c, "pci_disable_device" },
	{ 0x613e125b, "adf_dev_init" },
	{ 0x4b21bbcd, "adf_devmgr_update_class_index" },
	{ 0xf288fcdc, "pci_release_regions" },
	{ 0x7f5ed20b, "adf_dev_restore" },
	{ 0xc24601f8, "adf_dev_stop" },
	{ 0xd1c1af71, "adf_devmgr_rm_dev" },
	{ 0xa648e561, "__ubsan_handle_shift_out_of_bounds" },
	{ 0x35b97737, "dma_set_coherent_mask" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x1e323c29, "pci_set_master" },
	{ 0xb456d07, "adf_dev_shutdown" },
	{ 0x131d4cde, "adf_cfg_dev_add" },
	{ 0xbd1fc1a3, "pci_iounmap" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0x7df9c00c, "debugfs_remove" },
	{ 0xd0091a8c, "adf_cfg_dev_remove" },
	{ 0xc927638e, "adf_pfvf_debugfs_add" },
	{ 0x79161eb9, "_dev_err" },
	{ 0x992104a3, "adf_vqat2vdcm_shutdown" },
	{ 0x6d781a09, "adf_reset_flr" },
	{ 0xdcafa406, "adf_devmgr_add_dev" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0x54646bc4, "pci_select_bars" },
	{ 0xe29afbca, "kmem_cache_alloc_node_trace" },
	{ 0x5e54114c, "adf_cfg_add_key_value_param" },
	{ 0x7af7def, "adf_dev_start" },
	{ 0xce53684f, "vqat_init_hw_csr_info" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x3c48187b, "adf_disable_vqat_iov" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x233f929e, "pci_unregister_driver" },
	{ 0xf35141b2, "kmem_cache_alloc_trace" },
	{ 0x85c21616, "__dynamic_dev_dbg" },
	{ 0x40899d41, "adf_config_device" },
	{ 0xb302b6e3, "adf_enable_vqat_iov" },
	{ 0x37a0cba, "kfree" },
	{ 0xcc3b167a, "adf_clean_vf_map" },
	{ 0x69acdf38, "memcpy" },
	{ 0x95b52781, "pci_request_regions" },
	{ 0xf2bb7d9, "__pci_register_driver" },
	{ 0x3f2eb804, "adf_vqat_isr_resource_alloc" },
	{ 0x608741b5, "__init_swait_queue_head" },
	{ 0xa2090248, "adf_devmgr_pci_to_accel_dev" },
	{ 0x5abe6508, "adf_vqat2vdcm_init" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x518022d6, "pci_iomap" },
	{ 0x8d929026, "pci_enable_device" },
	{ 0x6e053cc4, "pci_save_state" },
};

MODULE_INFO(depends, "intel_qat");

MODULE_ALIAS("pci:v00008086d00000DA5sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "FF25A68433A3527B2417D1F");
